# Bangla Cartoon Studio

Starter Flutter app. Current version creates a scene plan from a Bangla story.
It does not yet generate AI images, voices, animated video, or MP4 files.
