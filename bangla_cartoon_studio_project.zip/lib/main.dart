import 'package:flutter/material.dart';

void main() => runApp(const BanglaCartoonApp());

class BanglaCartoonApp extends StatelessWidget {
  const BanglaCartoonApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bangla Cartoon Studio',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6558D3)),
        scaffoldBackgroundColor: const Color(0xFFF6F5FB),
      ),
      home: const StudioHome(),
    );
  }
}

class StudioHome extends StatefulWidget {
  const StudioHome({super.key});

  @override
  State<StudioHome> createState() => _StudioHomeState();
}

class _StudioHomeState extends State<StudioHome> {
  final _storyController = TextEditingController();
  String _style = '3D Cartoon';
  String _language = 'বাংলা';
  String _format = 'YouTube 16:9';
  bool _includeVoice = true;
  bool _includeCaptions = true;
  bool _includeMusic = true;
  bool _busy = false;
  String _result = '';

  @override
  void dispose() {
    _storyController.dispose();
    super.dispose();
  }

  Future<void> _createPlan() async {
    final story = _storyController.text.trim();
    if (story.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('আগে আপনার গল্পটি লিখুন।')),
      );
      return;
    }

    setState(() {
      _busy = true;
      _result = '';
    });

    // This first version creates a scene plan locally.
    // AI image/video generation and MP4 rendering need an AI backend
    // and a video-rendering service or additional native packages.
    await Future<void>.delayed(const Duration(milliseconds: 450));

    final sentences = story
        .split(RegExp(r'[।.!?]\s*'))
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();

    final scenes = sentences.isEmpty ? <String>[story] : sentences;
    final buffer = StringBuffer()
      ..writeln('আপনার কার্টুন ভিডিওর পরিকল্পনা')
      ..writeln('স্টাইল: $_style')
      ..writeln('ভাষা: $_language')
      ..writeln('ফরম্যাট: $_format')
      ..writeln('মোট দৃশ্য: ${scenes.length}')
      ..writeln('');

    for (var i = 0; i < scenes.length; i++) {
      buffer.writeln('দৃশ্য ${i + 1}: ${scenes[i]}');
      buffer.writeln('ছবির নির্দেশনা: $_style কার্টুন, গল্পের সঙ্গে মানানসই পরিবেশ, একই চরিত্রের চেহারা বজায় রাখুন।');
      if (_includeVoice) buffer.writeln('ভয়েস: স্পষ্ট বাংলা বর্ণনা');
      if (_includeCaptions) buffer.writeln('সাবটাইটেল: ${scenes[i]}');
      buffer.writeln('');
    }

    setState(() {
      _result = buffer.toString();
      _busy = false;
    });
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10, top: 18),
      child: Row(
        children: [
          Icon(icon, size: 20, color: const Color(0xFF6558D3)),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }

  Widget _dropdown({
    required String label,
    required String value,
    required List<String> options,
    required ValueChanged<String?> onChanged,
  }) {
    return DropdownButtonFormField<String>(
      value: value,
      decoration: InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      ),
      items: options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: onChanged,
    );
  }

  Widget _switchTile(String title, bool value, ValueChanged<bool> onChanged) {
    return SwitchListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(title),
      value: value,
      onChanged: onChanged,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Bangla Cartoon Studio', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: false,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF6558D3), Color(0xFF9B67D8)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.movie_creation_outlined, color: Colors.white, size: 34),
                  SizedBox(height: 12),
                  Text('আপনার গল্প, আপনার কার্টুন!',
                      style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('বাংলা শিক্ষামূলক, ব্যবসা ও সফলতার গল্পের জন্য ভিডিও পরিকল্পনা তৈরি করুন।',
                      style: TextStyle(color: Colors.white, height: 1.4)),
                ],
              ),
            ),
            _sectionTitle('১. গল্প লিখুন', Icons.edit_note),
            TextField(
              controller: _storyController,
              minLines: 5,
              maxLines: 10,
              decoration: InputDecoration(
                hintText: 'উদাহরণ: এক তরুণ ছোট ব্যবসা শুরু করল। প্রথমে সে ব্যর্থ হলো, কিন্তু শেখা ও পরিশ্রম চালিয়ে গেল...',
                filled: true,
                fillColor: Colors.white,
                alignLabelWithHint: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              ),
            ),
            _sectionTitle('২. ভিডিও সেটিংস', Icons.tune),
            _dropdown(
              label: 'কার্টুনের ধরন',
              value: _style,
              options: const ['2D Cartoon', '3D Cartoon', 'Anime', 'Kids Educational'],
              onChanged: (v) => setState(() => _style = v ?? _style),
            ),
            const SizedBox(height: 12),
            _dropdown(
              label: 'ভাষা',
              value: _language,
              options: const ['বাংলা', 'English', 'বাংলা + English'],
              onChanged: (v) => setState(() => _language = v ?? _language),
            ),
            const SizedBox(height: 12),
            _dropdown(
              label: 'ভিডিওর অনুপাত',
              value: _format,
              options: const ['YouTube 16:9', 'YouTube Shorts 9:16', 'Square 1:1'],
              onChanged: (v) => setState(() => _format = v ?? _format),
            ),
            _sectionTitle('৩. ভিডিওতে কী থাকবে?', Icons.auto_awesome),
            _switchTile('বাংলা ভয়েসের পরিকল্পনা', _includeVoice,
                (v) => setState(() => _includeVoice = v)),
            _switchTile('বাংলা সাবটাইটেল', _includeCaptions,
                (v) => setState(() => _includeCaptions = v)),
            _switchTile('ব্যাকগ্রাউন্ড মিউজিকের পরিকল্পনা', _includeMusic,
                (v) => setState(() => _includeMusic = v)),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _busy ? null : _createPlan,
              icon: _busy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.movie_filter_outlined),
              label: Text(_busy ? 'তৈরি হচ্ছে...' : 'ভিডিওর দৃশ্য পরিকল্পনা তৈরি করুন'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            if (_result.isNotEmpty) ...[
              _sectionTitle('আপনার দৃশ্য পরিকল্পনা', Icons.check_circle_outline),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFE1DDF4)),
                ),
                child: SelectableText(_result, style: const TextStyle(height: 1.55)),
              ),
              const SizedBox(height: 10),
              const Text(
                'নোট: এটি প্রাথমিক অ্যাপ সংস্করণ। এটি এখন গল্পকে দৃশ্যের পরিকল্পনায় সাজায়; AI ছবি/চলমান ভিডিও তৈরি বা MP4 এক্সপোর্ট করতে পরবর্তী ধাপে AI API ও ভিডিও রেন্ডারিং যুক্ত করতে হবে.',
                style: TextStyle(fontSize: 12, color: Colors.black54, height: 1.4),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
